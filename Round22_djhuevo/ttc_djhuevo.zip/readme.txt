Just da Monkey

no time for sound

It was done with 4 fps in mind, I only have tested it in PCSX2

thanx goes to neofar, m3ntol, Erion, Jules, Raizor and my great friend Hermes!!


