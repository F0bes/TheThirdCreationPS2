A little entry for TTC18. Very basic and not too exciting.

Code & Gfx: Raizor
Music: Pink/Abyss

Didn't have time to get any VU stuff sorted yet. Hoping
something gets done before next time...

Raizor

ps. Should run fine under PAL & NTSC.


