BOREDOM Part 2 (TyRaNiD) R#8 demo

Ok this is even duller than the original, at least that had something going on.

Anyway watch the 3d text scrolly which i'll grant is at least rendered on the vu1 so give me a little
credit for that at least :)

Oh and a point to note, plug a pad into pad one and:-

Press Cross to switch to PAL video mode
      Circle to switch to NTSC video mode
      Triangle to pause and unpause the mod

Thx to vzzrzzf for his module player which quite frankly rocks, and adresd+blackdroid for being annoying :P

Have fun, looking at the better demos of round 8.

