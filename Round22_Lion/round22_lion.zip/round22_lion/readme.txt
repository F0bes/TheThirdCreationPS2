title: Speaker Box
by   : Lion
for  : Round 22


greetz to: duke[Npm], oobles, loser, bd_code, mr brown,  sjeep.