//---------------------------------------------------------------------------
// File:	ps2.h
// Author:	Tony Saveski, t_saveski@yahoo.com
// Note:	PS2 System Routines
//---------------------------------------------------------------------------
#ifndef PS2_H
#define PS2_H

#include "defines.h"

#ifdef __cplusplus
extern "C" {
#endif

extern void ps2_flush_cache(int blah);

#ifdef __cplusplus
}
#endif

#endif // PS2_H
