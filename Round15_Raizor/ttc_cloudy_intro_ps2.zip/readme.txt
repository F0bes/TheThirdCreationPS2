Just a little intro for TTC.

Code & gfx by Raizor
Music by Laxity/Kefrens (taken from the amiga Desert Dream intro)

Not technically impressive in the slightest.  But I think it looks OK for a first attempt ;P

The code is very messy, I'll clean it up when I get time and release the sourcecode in case anyone wants to look at it (as if).  I've only been able to test it on a PAL console, but it should work fine.  Tested with Naplink only so far...

If the intro can't find a copy of LIBSD, it will go into no-sound mode.

I must say thanks to LongChair, MrBrown and Dreamtime for all the help getting me started with the PS2 development.  LongChair spent hours helping me to get my compilers set up and running via the .Net IDE (top man!).  Dreamtimes tutorials provided a great start to getting things running on the PS2.  And of course MrBrown patiently answered a whole load of my dumb questions and saved me a lot of headaches...

Until next time (and something better),

Raizor / RiSK