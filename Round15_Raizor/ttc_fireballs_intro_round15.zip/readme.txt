Fireballs
---------

Another little intro for TTC

Code & gfx by Raizor
Music by Estrayk / Paradox

Yet another quick (rushed) intro for TTC. Hopefully a bit nicer than the last one. My grand plans for an impressive multi-effect demo have so far been scuppered by time constraints and lack of coding prowess/experience.

This is some homemade homebrew fire. An effect seen many times before. It was just some practice at pixel filtering really...

Notes:

If the intro can't find a copy of LIBSD or amigamod.irx, it will go into no-sound mode.

I've only been able to test this on a PAL machine, which works fine. I butchered the code to simulate an NTSC machine (which also worked), there was a little slowdown under NTSC, but that should be fixed now :P

You'll need a pad plugged into the ps2. I was working on having some interactivity but it didn't make it in time. Logistical (moving house) problems mean I am unable to make any more edits to the code at the moment. I'll release a fixed version as soon as possible.

Raizor / RiSK


