
#============================================================================>
#      MMMMMMM  OOOO   U    U TTTTTTT H    H SSSSSSS H    H U    U TTTTTTT
#      M  M  M O    O  U    U    T    H    H S       H    H U    U    T   
#      M  M  M O    O  U    U    T    H    H S       H    H U    U    T   
#      M  M  M O    O  U    U    T    HHHHHH SSSSSSS HHHHHH U    U    T   
#      M  M  M O    O  U    U    T    H    H       S H    H U    U    T   
#      M  M  M 0    0  U    U    T    H    H       S H    H U    U    T   
#      M  M  M  0000    UUUU     T    H    H SSSSSSS H    H  UUUU     T      
#               "AS LONG AS YOU LEARN YOU WILL MAKE MISTAKES"
#============================================================================>


#============================================================================>
# Sony Playstation 2 Demo : Damn by Jules / www.mouthshut.net
#============================================================================>

Released on 3rd 2003 for round #13 of The Third Creation (TTC) demo contest,
website at www.thethirdcreation.net

#============================================================================>
# About this demo
#============================================================================>

This is actually the 2nd version of the demo i sent to TTC, this one features
antialiasing and sound :)

I took me about one week to make, mainly coz i had to fight with vu0 code. I
know what you are thinking, Damn - it sucks. But i am quite happy with it,
although i didn't have time to shading and other fancy features, that will
have to wait until next round - I already got some ideas :)

Features:
This demo uses vu0 for all matrix/vector math (except projection) coded
from scratch by me and also SifRpc code reversed from scratch also by me.
These features and more will be the next version ito :D

Notes:
The demo will try to load LIBSD from rom0 first, then libsd.irx (lowercase)
from host0, if none of them are loaded succesfully no sound will be played.

#============================================================================>
# Credits
#============================================================================>

Code/"Gfx"/3D Model : Jules
Modplayer: Amigamod by Vzzrzzn
Music "Shortdogkick" by Sean Bishop

#============================================================================>
# Greets fly out to..
#============================================================================>
 Adresd - Blackdroid - Deature - Dreamtime - Gustav Scotti - Hanimar
 Icewatus - jenova0 - Karmix - LongChair - Marcus R Brown - Nagra - Napalm
 NoRecess - Oobles - Pukko - sg2 - Sjeep - Soopadoopa - Stryder Hiryu
 Tyranid - Vzzrzzn

