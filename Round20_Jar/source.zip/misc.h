#ifndef MISC_H_INCLUDED
#define MISC_H_INCLUDED

// fra rawtoasm
#define DEFINE_BINARY_DATA(x) extern char binary_ ## x ## _start[]; extern char binary_ ## x ## _end[]

// print en float med 1000ende dels precision paa formen IIIIII.FFF
#define printfloat_1000(x) { float _temp__=x; const char* sign=""; if(_temp__<0){_temp__=-_temp__; sign="-";} nprintf(#x " = %s%d.%3.3d\n", sign, (int)_temp__, (int)(_temp__*1000)%1000); }
#define printfloat_1000_simple(x) { float _temp__=x; const char* sign=""; if(_temp__<0){_temp__=-_temp__; sign="-";} nprintf("%s%d.%3.3d ", sign, (int)_temp__, (int)(_temp__*1000)%1000); }


#define printvec(x,y,z,w) { printfloat_1000_simple(x) printfloat_1000_simple(y) printfloat_1000_simple(z) printfloat_1000_simple(w) nprintf("\n"); }
#define printvecf(p) printvec((p)[0],(p)[1],(p)[2],(p)[3])

#define ADDRESS_OF(a) ((u32)(a))
#define WORD_COUNT(a) (((a)+3)/4)		// 32bit
#define DWORD_COUNT(a) (((a)+7)/8)		// 64bit
#define QWORD_COUNT(a) (((a)+15)/16)	// 128bit

extern s32 random();
extern float f_random();
extern void flush_cache(int);
extern void gs_init(void);
extern void read_file(const char* filename, void** ptr, int* size);
extern void write_file(const char* fname, void* ptr, int size);
extern void dumpmem(volatile void* beg_, volatile void* end_);
extern void comparemem(volatile void* beg_, volatile void* end_, volatile void* beg2_);

#endif
