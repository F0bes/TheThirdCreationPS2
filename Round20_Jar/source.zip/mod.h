extern void mod_init();
extern void mod_load(char* beg, char* end);
extern void mod_play();
extern void mod_getpos(int* order, int* row);
extern void mod_quit();
extern void mod_pause();
