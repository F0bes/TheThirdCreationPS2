#include <tamtypes.h>
#include "misc.h"
#include "gif.h"
#include "texture.h"

#define BLOCKSIZE 8192
#define BLOCKSIZEW 64
#define BLOCKSIZEH 32

#define gif_active() ((GIF_STAT & (2<<10)) != 0)

extern void dma_reset();
extern void gfx_init();
extern void gfx_flip_screen();
extern void gfx_vsync();
extern void gfx_allocinit(int start);
extern int gfx_allocvideomem(int size);
extern void gfx_set_texmem_base();
extern void gfx_reset_texmem();
extern void gfx_clearscreen(u64 color);
extern void gfx_draw_background(texture* tex, int alpha);
extern void gfx_set_register(u64 reg, u64 dat); // inefficient!
extern int gfx_add_vsync_callback(int (*func_ptr)(int));
extern int128 dma_list[];
extern int gfx_pal;
