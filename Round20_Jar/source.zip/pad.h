#include <libpad.h>

extern void pad_init();
extern void pad_get_button_state(struct padButtonStatus* button_status);
extern u32 pad_state_from_status(struct padButtonStatus* button_status);
