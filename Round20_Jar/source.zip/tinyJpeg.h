/******************************************************************************
 * texjpgtinyread.h - JPEG Tiny Texture Read                                  *
 ******************************************************************************
 * Project      : jfyeNG                                                      *
 * Author       : Arnaud Storq (norecess@planet-d.net)                        *
 * Based on work of Jeff Frohwein (www.devrs.com/gba), IJG (www.ijg.org) and  *
 *                Dmitry Brant (www.dmitrybrant.com)                          *
 ******************************************************************************/
#ifndef _TEX_JPG_TINY_READ_
#define _TEX_JPG_TINY_READ_

/*---------------------------------------------------------------------------- GLOBAL FUNCTIONS */
u32 JpgTinyRead(u8 *src, u8 **dst, s32 *width, s32 *height, s32 *depth);

/*---------------------------------------------------------------------------- END OF DECLARATION */
#endif /* _TEX_JPG_TINY_READ_ */
