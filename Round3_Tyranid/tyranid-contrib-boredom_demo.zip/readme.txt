BOREDOM - PS2 Demo by TyRaNiD (tiraniddo at hotmail dot com)

This is a nice and simple demo for the PS2. There are two versions available, one which runs
native using naplink and another which will run under PS2 linux.

The mod player is the one by written by adresd, all credit to you man. 
The mod i collected along time ago so I dont remeber where i got it, probably the original song 
it comes from is copyrighted but then it isnt an actual copy it's a performance of so should not 
be a problem ;)

The demo has been tested on a euro PS2 console only, however NTSC mode has been checked and is the
optimal mode for running the demo. Runs perfectly well in PAL.

You will need a PS2 with the libsd module in rom or get hold of libsd.irx and put it in the same 
directory as the demo. The demo also requires Sjeep's PCM irx but that should be included. This doesn't 
apply to ps2linux version obviously :)

It is worth noting that the PS2 Linux version will _NOT_ work on a monitor. I neither have the capability
(monitor wise) nor the desire to waste precious VRAM with hi-res graphics ;) Therefore this demo will
only work when using a TV for display. Of course it can probably be bodged to work on a monitor. 

Also the screen mode will be taken from the current crt setting so if you running in PAL it will work in
PAL, this will happen even if you are running it on a NTSC machine. Use setcrtmode to set which format
you want before running.

L8rs

Thx 'n' Greetz

Thx to adresd, Sjeep, Dreamtime, Oobles for the work you put into the ps2dev community. 
Other ppl I aint mentioned ;)
