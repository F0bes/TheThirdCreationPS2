Waves, micro demo for r10 of ThirdCreation
Written by TyRaNiD

Ok erm, this is a check board waving utilising a timer and interrupt
to modify display2 while drawing. 

That is all, dont sit there waiting for something to happen :)

Ive provided the source because while it seems to work fine in NTSC it does not
in PAL so there is no pal mode enabled in the demo, maybe your clever enough
to fix it :)

Im stumped, bd didnt find a solution in time so ask your self, do you feel 
lucky punk ?

Anyway 'los and greetz to :-

Blackdroid, adresd, pukko (nice smap loader :P), and the usual motley crew
of vagrants who hang around #ps2dev, #psx2dev

"Oh we put that in for a joke, see you next year!!"
