- The Poor Demo -
Created by KaL{Ir}  30/08/2003

This demo is just a test with dreamgl...
I spent most of the time setting up the lib and compilers.
