P51 Mustang By LongChair
========================

1 ) What's that stuff ?
----------------------

Well i'd say it's some kinda implementation of 3D on PS2 using 
texture mapping and simple shading.

3 ) How was this made ?
-----------------------

Well basically i used the Devkit provided on http://ps2dev.livemedia.com.au

I didn't release the sources for one simple reason. It's been made with some 
code taken from Fun Slower Demo and dreamtime tutorial which you will be able to find
on ps2dev ... and i added some more 3D code home made. The whole of it is a bit messy
and that's the main reason i won't release it :)

i used an home made converter for converting 3D mesh to C statically linked files.
the former mesh come from www.almathea3d.com. Thanx to them for this nice mash.

Special greets go to :
- Fun Slower Demo 
- Dreamtime's tutorial (very nice effort)
- people on #ps2dev which i bother all the time with my questions ( i know i am a pain in teh ass :))
	Specially : struct2, Jules', Oobles, Sjeep and all the others :)

- also gustavo scotty for the PS2lib and Pukko for the Padlib code which is used in this elf.

4 ) What else
-------------

i hope i'll be able to package a bit more my next prod and add some more nicer stuff ..

have fun & enjoy :)

LongChair.

