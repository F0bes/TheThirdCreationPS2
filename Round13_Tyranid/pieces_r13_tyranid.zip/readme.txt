PIECES TheThirdCreation.Net R#13 demo by TyRaNiD

If you have a pad plugged into pad 1 slot on startup then you can select output type.
Cross gives NTSC and Circle gives PAL. I would highly recommend using the NTSC mode ;)

Thx to vzzrzzf for his module player which quite frankly rocks, I would have put your name in the main scoller but quite frankly your name is too long for the time limit ;P
Usual thx to blackdroid 'n' adresd for help etc.

l8rs

