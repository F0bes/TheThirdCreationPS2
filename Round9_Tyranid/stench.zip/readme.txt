STENCH - a micro demo for round 9 of the third creation PS2 demo compo
Written by TyRaNiD

Well as its name suggests (or not :P) this is a sub 1kb demo for PS2 which simulates
PONG sortof. Anyway what do you want for 1k.

Greetz & Thx

Adresd, Blackdroid, wiRe, Napalm in general, Jules and all the other members of #ps(x)2dev

Apologies to Jules for stealing his micro demo idea, and that I released before him.
