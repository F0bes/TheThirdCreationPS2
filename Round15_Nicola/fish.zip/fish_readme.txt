Fish by Nicola Farina.
----------------------
This is my second demo effort with PS2.

It uses a slightly modified version of dream_gl from
dreamtime with my efforts on vu0 asm.

Texture mapping also by me.
